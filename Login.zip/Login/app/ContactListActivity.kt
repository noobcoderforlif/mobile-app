package com.example.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.login.databinding.ActivityContactListBinding

class ContactListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactListBinding
    private lateinit var contactAdapter: ContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Sample Data (Replace with your actual contact data)
        val contacts = kotlin.collections.listOf(
            Contact("John Doe", "123-456-7890"),
            Contact("Jane Smith", "987-654-3210"),
            Contact("Peter Jones", "555-123-4567"),
            Contact("Maria Garcia", "555-987-6543"),
            Contact("David Lee", "555-456-1234")
        )

        // Set up RecyclerView
        binding.contactsRecyclerView.layoutManager = LinearLayoutManager(this)
        contactAdapter = ContactAdapter(contacts)
        binding.contactsRecyclerView.adapter = contactAdapter
    }
}